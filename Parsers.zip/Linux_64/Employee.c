#include <stdio.h>
#include <stdlib.h>
#include "Employee.h"

Employee* employee_newParametros(char* idStr,char* nombreStr,char* horasTrabajadasStr,char* sueldo)
{
    return NULL;
}



